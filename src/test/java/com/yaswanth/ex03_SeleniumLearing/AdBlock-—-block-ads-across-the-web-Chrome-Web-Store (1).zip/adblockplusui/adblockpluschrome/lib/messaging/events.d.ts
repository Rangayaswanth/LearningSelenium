export function installHandler(type: string, action?: string | undefined, install: Function): void;

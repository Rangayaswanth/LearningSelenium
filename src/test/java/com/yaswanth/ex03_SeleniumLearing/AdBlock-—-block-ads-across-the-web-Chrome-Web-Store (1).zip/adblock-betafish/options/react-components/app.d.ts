export function App({ optionsData }: {
    optionsData: any;
}): import("react").JSX.Element;

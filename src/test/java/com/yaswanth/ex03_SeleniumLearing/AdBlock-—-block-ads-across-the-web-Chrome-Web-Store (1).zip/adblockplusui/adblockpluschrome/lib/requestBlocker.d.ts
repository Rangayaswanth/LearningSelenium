export let filterTypes: Set<any>;

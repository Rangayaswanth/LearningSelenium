export default class InlineLinkButton extends HTMLElement {
    connectedCallback(): Promise<void>;
}

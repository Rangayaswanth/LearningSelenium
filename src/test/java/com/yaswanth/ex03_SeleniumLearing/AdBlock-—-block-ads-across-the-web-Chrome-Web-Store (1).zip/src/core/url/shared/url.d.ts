export declare function isActiveOnDomain(url: string, domainList?: string): boolean;
export declare function isDomainList(list: string): boolean;

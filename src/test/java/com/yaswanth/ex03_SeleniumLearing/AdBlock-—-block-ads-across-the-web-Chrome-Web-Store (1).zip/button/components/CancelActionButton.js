/*
 * This file is part of AdBlock  <https://getadblock.com/>,
 * Copyright (C) 2013-present  Adblock, Inc.
 *
 * AdBlock is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * AdBlock is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdBlock.  If not, see <http://www.gnu.org/licenses/>.
 */

/* For ESLint: List any global identifiers used in this file below */
/* global translate */

export default class CancelActionButton extends HTMLElement {
  connectedCallback() {
    const backButton = document.createElement("button");
    const buttonLabel = translate("no_thanks_label");

    backButton.ariaLabel = buttonLabel;
    backButton.innerText = translate("no_thanks");
    backButton.addEventListener("click", () => {
      window.history.back();
    });

    this.appendChild(backButton);
  }
}

export function GeneralOptionsTab({ subs, settings, prefsNames }: {
    subs: any;
    settings: any;
    prefsNames: any;
}): import("react").JSX.Element;

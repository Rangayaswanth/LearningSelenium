declare function topOpenBlacklistUI(options: any): void;

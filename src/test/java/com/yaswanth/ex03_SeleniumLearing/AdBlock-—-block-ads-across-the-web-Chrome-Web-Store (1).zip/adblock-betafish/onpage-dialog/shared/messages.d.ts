import { type PingMessage } from "./messages.types";
export declare function isPingMessage(candidate: unknown): candidate is PingMessage;

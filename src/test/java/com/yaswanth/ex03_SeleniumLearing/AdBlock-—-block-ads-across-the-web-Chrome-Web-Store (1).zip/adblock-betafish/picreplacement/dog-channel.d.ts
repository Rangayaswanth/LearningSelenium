export default DogsChannel;
declare class DogsChannel extends Channel {
    getLatestListings(callback: any): void;
}
import Channel from "./channel";

export default class CancelActionButton extends HTMLElement {
    connectedCallback(): void;
}

export default UnknownChannel;
declare class UnknownChannel extends Channel {
    getLatestListings(callback: any): void;
}
import Channel from "./channel";

declare function cleanCustomFilter(filtersArg: any): Promise<any>;
declare function showCustomRules(): Promise<void>;
declare function onFilterChange(): Promise<void>;
declare let originalCustomFilters: any[];
declare const excludeFiltersKey: "exclude_filters";

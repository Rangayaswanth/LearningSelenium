export default class MenuLink extends HTMLElement {
    connectedCallback(): Promise<void>;
    pageInfo: any;
}

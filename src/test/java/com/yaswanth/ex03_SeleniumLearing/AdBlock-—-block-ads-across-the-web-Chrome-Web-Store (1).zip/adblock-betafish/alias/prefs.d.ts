export namespace Prefs {
    const untilLoaded: Promise<void>;
}

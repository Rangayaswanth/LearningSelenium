export function setUninstallURL(): Promise<void>;

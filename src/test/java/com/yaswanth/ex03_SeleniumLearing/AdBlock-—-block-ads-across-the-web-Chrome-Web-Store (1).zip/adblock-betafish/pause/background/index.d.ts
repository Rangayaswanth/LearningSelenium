export function adblockIsDomainPaused(activeTab: any, newValue: any, sessionOnly?: boolean, origin?: FilterOrigin): any;
export function adblockIsPaused(newValue: any): boolean | undefined;
export const pausedFilterText1: "@@*";
export const pausedFilterText2: "@@*$document";
export function saveDomainPauses(domainPauses: any): void;
import { FilterOrigin } from "../../../src/filters/shared/filter.types";

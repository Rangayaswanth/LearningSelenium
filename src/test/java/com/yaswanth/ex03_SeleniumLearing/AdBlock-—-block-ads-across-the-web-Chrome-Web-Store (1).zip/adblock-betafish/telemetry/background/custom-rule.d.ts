export function getWebAllowlistingFilterCount(): number;
export function getPopupAllowlistingFilterCount(): number;
export function getCustomizedFilterCount(): number;
export function getWizardFilterCount(): number;
export function getMissingFilterCount(): number;

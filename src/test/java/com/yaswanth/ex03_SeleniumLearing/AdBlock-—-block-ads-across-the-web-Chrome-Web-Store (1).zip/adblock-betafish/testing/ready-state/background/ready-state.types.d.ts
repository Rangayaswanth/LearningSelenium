export declare enum ReadyState {
    loading = "loading",
    started = "started"
}

export declare function checkLanguage(ipmId: string): Promise<void>;

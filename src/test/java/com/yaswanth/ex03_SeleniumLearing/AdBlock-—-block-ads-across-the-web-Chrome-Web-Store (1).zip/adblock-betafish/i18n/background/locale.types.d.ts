export interface LocaleInfo {
    locale: string;
    readingDirection: string;
}

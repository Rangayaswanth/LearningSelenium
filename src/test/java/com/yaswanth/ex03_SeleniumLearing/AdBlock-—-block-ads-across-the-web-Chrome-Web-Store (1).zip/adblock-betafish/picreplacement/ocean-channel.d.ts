export default OceanChannel;
declare class OceanChannel extends Channel {
    getLatestListings(callback: any): void;
}
import Channel from "./channel";

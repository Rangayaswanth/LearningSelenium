export const migrateUserData: () => Promise<void>;
export { getSettings, isValidTheme, setSetting, settings, settingsNotifier } from "./settings";

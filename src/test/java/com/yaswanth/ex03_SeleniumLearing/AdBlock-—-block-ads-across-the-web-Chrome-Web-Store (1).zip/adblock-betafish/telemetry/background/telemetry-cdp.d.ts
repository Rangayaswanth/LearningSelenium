export function startCdpOptOutListener(): Promise<void>;

export default function postData(url?: string, payload?: {}): Promise<Response>;

import { UserAgentInfo } from "./user-agent-info.types";
export declare function getUserAgentInfo(): UserAgentInfo;

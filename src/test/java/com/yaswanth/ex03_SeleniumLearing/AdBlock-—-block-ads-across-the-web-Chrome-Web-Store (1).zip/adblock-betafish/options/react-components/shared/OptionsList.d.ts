export function OptionsList({ items, isChecked }: {
    items: any;
    isChecked: any;
}): import("react").JSX.Element;
